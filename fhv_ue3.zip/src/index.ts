import './style/index.css';
import App from './components/app';

export default App;
